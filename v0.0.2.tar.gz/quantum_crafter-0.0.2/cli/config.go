package cli

const (
	Version = "v0.0.2"
	RepoURL = "https://github.com/mattrltrent/quantum_crafter"
)
