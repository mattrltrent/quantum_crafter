package main

import (
	"github.com/mattrltrent/quantum_crafter/cli"
)

func main() {
	cli.Run()
}
